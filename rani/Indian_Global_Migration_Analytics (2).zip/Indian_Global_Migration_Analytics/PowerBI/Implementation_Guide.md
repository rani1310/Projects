# Power BI Implementation Guide
Get from these files to a working Power BI report in under 5 minutes.

## What's in this folder
| File | Purpose |
|---|---|
| `PowerQuery_M_Script.pq` | Paste into Power Query's Advanced Editor to load + type the data |
| `DAX_Measures.txt` | 12 ready-to-paste DAX measures with explanations |
| `Star_Schema_Design.md` | The fact/dimension table design and why |
| `../Cleaned_Data/cleaned_migration_data.csv` | The data file the M script loads |

## Step-by-Step

### 1. Get the data file onto your machine
Download `cleaned_migration_data.csv` (from `Cleaned_Data/` in the project
zip) and note its folder path — you'll need it in Step 3.

### 2. Open Power BI Desktop → new report
`Home` ribbon → `Transform Data` → this opens the Power Query Editor.

### 3. Load the data via the M script
- `Home` → `Advanced Editor`
- Delete the placeholder text, paste in the contents of `PowerQuery_M_Script.pq`
  (just the first `let...in` block — the Calendar table and raw-data
  alternative are separate blocks, commented out, further down the file)
- **Update the file path** in the `Source` step to match where you saved
  the CSV (e.g. `C:\Users\YourName\Downloads\cleaned_migration_data.csv`)
- Click `Done`, rename the query to `Migration Fact` (right panel), then
  `Home` → `Close & Apply`

### 4. Add the Calendar dimension table
- `Home` → `New Source` → `Blank Query` → `Advanced Editor`
- Paste in the commented-out Calendar block from the same `.pq` file
  (uncomment it first — remove the leading `//` from each line)
- Rename the query `Calendar`, `Close & Apply`

### 5. Add the Country dimension table
- In the Data pane, right-click → `New Table` (this uses DAX, not Power Query)
- Paste the `Dim_Country` DAX formula from `Star_Schema_Design.md`

### 6. Build relationships
- Go to `Model` view (left sidebar)
- Drag `Migration Fact[Year]` onto `Calendar[Year]`
- Drag `Migration Fact[Destination_Country]` onto `Dim_Country[Destination_Country]`
- Confirm both are Many-to-One, Single direction (Power BI usually infers
  this correctly automatically)

### 7. Add the DAX measures
- Right-click `Migration Fact` in the Data pane → `New Measure`
- Paste in each measure from `DAX_Measures.txt` one at a time (12 total)
- Optional: select all 12, right-click → `Properties` → set
  `Display Folder` to "Migration Measures" for a tidier field list

### 8. Build the report pages
Suggested pages, using the fields/measures now available:
- **Executive Summary**: Card visuals for `[Total Migrants]`, `[Countries
  Tracked]`, `[Average Migrants per Country]`; a slicer on `Dim_Country[Region]`
- **Country Trends**: Line chart, `Calendar[Year]` on X-axis, `[Total
  Migrants]` on Y-axis, `Dim_Country[Destination_Country]` as legend
- **Growth Analysis**: Bar chart of `[CAGR Migrants (2000-2024)]` by country;
  table with `[Rank Country by Migrants]`
- **Macro Indicators**: Combo chart of `India GDP (USD Billion)` and `India
  Unemployment (%)` over `Calendar[Year]`

### 9. Add interactivity
- Add a slicer on `Dim_Country[Region]` and `Calendar[Year]` to every page
  (use `Format > Sync Slicers` to sync them across pages)
- Add tooltips: create a small tooltip page showing YoY growth detail,
  then set it as a custom tooltip on the trend chart (`Format visual` →
  `General` → `Tooltips`)
- Bind the `[Dynamic Title - Selected Country]` measure to a Card visual
  placed at the top of the Country Trends page

### 10. Save as .pbix
`File` → `Save As` → choose `.pbix` format. This is now a real, complete
Power BI file you can open, edit, and publish from Power BI Desktop.

## Publishing online (free, using your own Microsoft account)
Power BI Desktop is free; publishing to the web requires a free Power BI
account (a work/school or Microsoft account) at https://app.powerbi.com —
Anthropic/Claude cannot create this account or host the report on your
behalf. Once you have an account:
- `Home` → `Publish` → choose your workspace → the report becomes viewable
  at a private `app.powerbi.com` link you can share with colleagues
- For a public, no-login link: `File` → `Publish to web` (Free/Pro accounts
  support this for reports without sensitive data — appropriate here since
  this dataset is all public-source figures)
