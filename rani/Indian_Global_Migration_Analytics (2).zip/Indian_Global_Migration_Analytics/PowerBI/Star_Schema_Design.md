# Power BI Star Schema Design

## Overview
A simple, robust star schema: one fact table plus two dimension tables.
Given the dataset's real grain (Year x Country, no state/gender/age
breakdown), a minimal schema is the correct design — adding synthetic
dimensions the data doesn't support would create fake granularity.

```
                    ┌─────────────────────┐
                    │   Dim_Country        │
                    │  ─────────────────── │
                    │  Destination_Country  │  (PK)
                    │  Destination_Country_ │
                    │    Full               │
                    │  Region               │
                    └───────────┬───────────┘
                                │ 1
                                │
                                │ *
                    ┌───────────┴───────────┐
                    │   Fact_Migration       │
                    │  ─────────────────────  │
                    │  YearCountryKey (PK)    │
                    │  Year (FK)              │
                    │  Destination_Country(FK)│
                    │  Total Migrants         │
                    │  Permanent Migrants     │
                    │  Temporary Workers      │
                    │  Students               │
                    │  India GDP (USD Billion)│
                    │  Remittances (USD Bn)   │
                    │  India Unemployment (%) │
                    │  [+ engineered columns] │
                    └───────────┬───────────┘
                                │ *
                                │
                                │ 1
                    ┌───────────┴───────────┐
                    │   Calendar             │
                    │  ─────────────────────  │
                    │  Year (PK)              │
                    │  YearStart              │
                    │  Decade                 │
                    └─────────────────────────┘
```

## Table Definitions

### Fact_Migration (grain: one row per Year x Destination Country)
The cleaned/engineered CSV (`cleaned_migration_data.csv`) loads directly as
this table. It already contains the surrogate key `YearCountryKey` added in
the Power Query script for clean relationship building.

### Dim_Country (grain: one row per country)
Created by removing duplicates from Fact_Migration on Destination_Country:
```
Dim_Country = DISTINCT(
    SELECTCOLUMNS(
        'Migration Fact',
        "Destination_Country", 'Migration Fact'[Destination_Country],
        "Destination_Country_Full", 'Migration Fact'[Destination_Country_Full],
        "Region", 'Migration Fact'[Region]
    )
)
```
Why it exists: keeps country attributes (Region, full name) in one place
so slicers/filters use a clean dimension instead of the (denormalized) fact
table directly — standard star-schema practice, and it lets Region-level
slicing work correctly without fanning out the fact table.

### Calendar (grain: one row per year, 2000–2026)
Built via the M script in `PowerQuery_M_Script.pq`. Why it exists: gives
Power BI a proper date/year hierarchy for time-intelligence visuals (trend
lines, year slicers) independent of which years happen to have fact data —
important here since migrant-count fields are sparse and you don't want
gaps in the fact table to silently create gaps in the Calendar's year axis.

## Relationships
| From | To | Cardinality | Cross-filter |
|---|---|---|---|
| Fact_Migration[Destination_Country] | Dim_Country[Destination_Country] | Many-to-One | Single |
| Fact_Migration[Year] | Calendar[Year] | Many-to-One | Single |

Both relationships should be set to **Single** direction cross-filtering
(Power BI default) — Both-direction filtering isn't needed here since there
is no bridge/many-to-many table in this simple model.

## Why NOT a snowflake or additional dimensions
The template this project was originally scoped against assumed Indian
state, gender, age-group, and education dimensions. The real source data
does not contain them. Building empty/fake dimension tables for those would
misrepresent data that doesn't exist — so this schema intentionally stays
to Year and Country, the two dimensions the data actually supports.
