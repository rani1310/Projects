"""
03_build_excel_report.py
-------------------------
Builds a single, polished Excel workbook for non-technical stakeholders:
  1. Executive Summary  - KPI cards (formulas) + native charts + takeaways
  2. Executive Insights  - the 10 insights, formatted for readability
  3. Migration Data      - the cleaned fact table (source for all formulas/charts)
  4. Data Quality Report - issues found, in table form
  5. Data Dictionary     - column definitions

All KPIs use formulas referencing the Migration Data sheet (not hardcoded
Python-computed values), per spreadsheet best practice, and avoid
functions LibreOffice's recalculation engine can't evaluate
(no XLOOKUP/array CSE formulas; MAXIFS/SUMIFS/AVERAGEIFS/SUMPRODUCT only).
"""
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.chart import BarChart, LineChart, Reference

SRC = "/home/claude/Indian_Global_Migration_Analytics/Cleaned_Data/cleaned_migration_data.csv"
OUT = "/home/claude/Indian_Global_Migration_Analytics/Reports/Migration_Analytics_Report.xlsx"

FONT = "Arial"
NAVY = "1F3864"
BLUE = "2E75B6"
LIGHT_BLUE = "DDEBF7"
GREY = "F2F2F2"
WHITE = "FFFFFF"
THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

df = pd.read_csv(SRC)
n = len(df)
LAST_ROW = n + 1  # data occupies rows 2..LAST_ROW on "Migration Data", header row 1

wb = Workbook()

# =============================================================================
# SHEET: Migration Data (built first so formulas elsewhere can reference it)
# =============================================================================
ws_data = wb.active
ws_data.title = "Migration Data"

cols = df.columns.tolist()
for j, col in enumerate(cols, start=1):
    cell = ws_data.cell(row=1, column=j, value=col.replace("_", " "))
    cell.font = Font(name=FONT, size=10, bold=True, color=WHITE)
    cell.fill = PatternFill("solid", fgColor=NAVY)
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

for i, row in df.iterrows():
    for j, col in enumerate(cols, start=1):
        val = row[col]
        if pd.isna(val):
            val = None
        cell = ws_data.cell(row=i + 2, column=j, value=val)
        cell.font = Font(name=FONT, size=10)
        if i % 2 == 1:
            cell.fill = PatternFill("solid", fgColor=GREY)

# Column widths + number formats
col_letter = {col: get_column_letter(idx + 1) for idx, col in enumerate(cols)}
for col in ["Total_Indian_Migrants", "Permanent_Migrants", "Temporary_Workers", "Students"]:
    if col in col_letter:
        for r in range(2, LAST_ROW + 1):
            ws_data[f"{col_letter[col]}{r}"].number_format = "#,##0"
for col in ["GDP_India_USD_Billion", "Remittance_USD_Billion", "Migrant_3yr_Moving_Avg"]:
    if col in col_letter:
        for r in range(2, LAST_ROW + 1):
            ws_data[f"{col_letter[col]}{r}"].number_format = "#,##0.0"
for col in ["Unemployment_India", "Migrant_YoY_Growth_Pct", "Temporary_Worker_Share_Pct", "Student_Share_Pct"]:
    if col in col_letter:
        for r in range(2, LAST_ROW + 1):
            ws_data[f"{col_letter[col]}{r}"].number_format = "0.00"

ws_data.freeze_panes = "A2"
for col in cols:
    idx = col_letter[col]
    max_len = max(len(col), 12)
    ws_data.column_dimensions[idx].width = max_len + 4

YEAR_COL = col_letter["Year"]
COUNTRY_COL = col_letter["Destination_Country"]
GDP_COL = col_letter["GDP_India_USD_Billion"]
REM_COL = col_letter["Remittance_USD_Billion"]
UNEMP_COL = col_letter["Unemployment_India"]
TOTAL_MIG_COL = col_letter["Total_Indian_Migrants"]

# =============================================================================
# SHEET: Executive Summary
# =============================================================================
ws = wb.create_sheet("Executive Summary", 0)
ws.sheet_view.showGridLines = False

ws["B2"] = "Indian Overseas Migration Analytics"
ws["B2"].font = Font(name=FONT, size=20, bold=True, color=NAVY)
ws["B3"] = "Executive Summary  |  Coverage: 2000-2024  |  7 Destination Countries"
ws["B3"].font = Font(name=FONT, size=11, italic=True, color="666666")

kpi_cells = [
    ("Total Records", f"=COUNTA('Migration Data'!{YEAR_COL}2:{YEAR_COL}{LAST_ROW})", "#,##0"),
    ("Countries Covered",
     f"=SUMPRODUCT(1/COUNTIF('Migration Data'!{COUNTRY_COL}2:{COUNTRY_COL}{LAST_ROW},"
     f"'Migration Data'!{COUNTRY_COL}2:{COUNTRY_COL}{LAST_ROW}))", "0"),
    ("Latest Year (Migrant Stock Data)",
     f'=_xlfn.MAXIFS(\'Migration Data\'!{YEAR_COL}2:{YEAR_COL}{LAST_ROW},'
     f"'Migration Data'!{TOTAL_MIG_COL}2:{TOTAL_MIG_COL}{LAST_ROW},\"<>\")", "0"),
    ("Total Migrants Tracked, 2024",
     f"=SUMIFS('Migration Data'!{TOTAL_MIG_COL}2:{TOTAL_MIG_COL}{LAST_ROW},"
     f"'Migration Data'!{YEAR_COL}2:{YEAR_COL}{LAST_ROW},2024)", "#,##0"),
    ("India GDP 2024 ($B)",
     f"=AVERAGEIFS('Migration Data'!{GDP_COL}2:{GDP_COL}{LAST_ROW},"
     f"'Migration Data'!{YEAR_COL}2:{YEAR_COL}{LAST_ROW},2024)", "#,##0"),
    ("Remittances 2024 ($B)",
     f"=AVERAGEIFS('Migration Data'!{REM_COL}2:{REM_COL}{LAST_ROW},"
     f"'Migration Data'!{YEAR_COL}2:{YEAR_COL}{LAST_ROW},2024)", "#,##0.0"),
]

row0 = 5
col_start = 2
card_width = 2
gap = 1
r, c = row0, col_start
for label, formula, numfmt in kpi_cells:
    cl = get_column_letter(c)
    ecl = get_column_letter(c + card_width - 1)
    ws.merge_cells(f"{cl}{r}:{ecl}{r}")
    cell = ws[f"{cl}{r}"]
    cell.value = label
    cell.font = Font(name=FONT, size=9, bold=True, color=WHITE)
    cell.fill = PatternFill("solid", fgColor=NAVY)
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.row_dimensions[r].height = 28

    ws.merge_cells(f"{cl}{r+1}:{ecl}{r+1}")
    vcell = ws[f"{cl}{r+1}"]
    vcell.value = formula
    vcell.number_format = numfmt
    vcell.font = Font(name=FONT, size=16, bold=True, color=BLUE)
    vcell.fill = PatternFill("solid", fgColor=LIGHT_BLUE)
    vcell.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[r+1].height = 30

    c += card_width + gap

# Takeaways
ta_row = row0 + 4
ws[f"B{ta_row}"] = "Headline Takeaways"
ws[f"B{ta_row}"].font = Font(name=FONT, size=13, bold=True, color=NAVY)

takeaways = [
    "UAE (3.25M) and USA (3.17M) are the largest tracked Indian migrant destinations as of 2024.",
    "Canada is the fastest-growing corridor: +490% since 2000 (217K -> 1.28M).",
    "UK growth lagged all tracked countries: only +70% since 2000, likely tied to post-Brexit visa tightening.",
    "Remittances to India grew ~10.7x (2000-2024), tracking India's GDP (r=0.98) far more than migrant headcount.",
    "India's GDP grew 8.3x over the same period with no corresponding slowdown in emigration.",
    "Workforce/student composition data is too sparse (2 of 182 records) to support a general trend claim.",
]
for i, t in enumerate(takeaways):
    cell = ws[f"B{ta_row+1+i}"]
    cell.value = f"-  {t}"
    cell.font = Font(name=FONT, size=10.5)
    ws.merge_cells(f"B{ta_row+1+i}:N{ta_row+1+i}")
    cell.alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[ta_row+1+i].height = 18

note_row = ta_row + 1 + len(takeaways) + 1
ws[f"B{note_row}"] = ("Note: migrant-stock figures are recorded only in benchmark years "
                       "(2000, 2005/2010, 2015, 2020, 2024). GDP, unemployment, and remittances "
                       "are India-wide national figures repeated across countries, not "
                       "country-specific. See 'Data Quality Report' tab for full detail.")
ws[f"B{note_row}"].font = Font(name=FONT, size=9, italic=True, color="808080")
ws.merge_cells(f"B{note_row}:N{note_row}")
ws[f"B{note_row}"].alignment = Alignment(wrap_text=True)
ws.row_dimensions[note_row].height = 32

for col in "ABCDEFGHIJKLMNO":
    ws.column_dimensions[col].width = 11

# ---------------------------------------------------------------------------
# Native charts on Executive Summary: build small helper tables (with
# formulas) elsewhere on the same sheet, out of the printed view, then chart them.
# ---------------------------------------------------------------------------
helper_row = note_row + 3
ws[f"B{helper_row}"] = "Chart Data (helper table - formulas pull from Migration Data)"
ws[f"B{helper_row}"].font = Font(name=FONT, size=9, italic=True, color="A6A6A6")

# Helper table 1: Total migrants by country, latest year (2024)
h1 = helper_row + 1
ws[f"B{h1}"] = "Country"
ws[f"C{h1}"] = "Migrants (2024)"
for k, country in enumerate(countries := sorted(df["Destination_Country"].unique().tolist())):
    rr = h1 + 1 + k
    ws[f"B{rr}"] = country
    ws[f"C{rr}"] = (f"=SUMIFS('Migration Data'!{TOTAL_MIG_COL}2:{TOTAL_MIG_COL}{LAST_ROW},"
                     f"'Migration Data'!{YEAR_COL}2:{YEAR_COL}{LAST_ROW},2024,"
                     f"'Migration Data'!{COUNTRY_COL}2:{COUNTRY_COL}{LAST_ROW},\"{country}\")")
    ws[f"C{rr}"].number_format = "#,##0"
h1_end = h1 + len(countries)

# Helper table 2: GDP & Remittance trend by year
years_sorted = sorted(df["Year"].dropna().unique().tolist())
years_sorted = [int(y) for y in years_sorted if y <= 2024]
h2 = h1_end + 3
ws[f"B{h2}"] = "Year"
ws[f"C{h2}"] = "India GDP ($B)"
ws[f"D{h2}"] = "Remittances ($B)"
for k, yr in enumerate(years_sorted):
    rr = h2 + 1 + k
    ws[f"B{rr}"] = yr
    ws[f"C{rr}"] = (f"=AVERAGEIFS('Migration Data'!{GDP_COL}2:{GDP_COL}{LAST_ROW},"
                     f"'Migration Data'!{YEAR_COL}2:{YEAR_COL}{LAST_ROW},{yr})")
    ws[f"D{rr}"] = (f"=AVERAGEIFS('Migration Data'!{REM_COL}2:{REM_COL}{LAST_ROW},"
                     f"'Migration Data'!{YEAR_COL}2:{YEAR_COL}{LAST_ROW},{yr})")
    ws[f"C{rr}"].number_format = "#,##0"
    ws[f"D{rr}"].number_format = "#,##0.0"
h2_end = h2 + len(years_sorted)

# Chart 1: Bar chart - migrants by country (2024)
bar = BarChart()
bar.type = "col"
bar.title = "Indian Migrant Stock by Country (2024)"
bar.y_axis.title = "Total Migrants"
bar.x_axis.title = "Country"
data_ref = Reference(ws, min_col=3, min_row=h1, max_row=h1_end)
cats_ref = Reference(ws, min_col=2, min_row=h1 + 1, max_row=h1_end)
bar.add_data(data_ref, titles_from_data=True)
bar.set_categories(cats_ref)
bar.width, bar.height = 16, 9
bar.legend = None
ws.add_chart(bar, f"F{note_row + 2}")

# Chart 2: Line chart - GDP & remittances trend
line = LineChart()
line.title = "India GDP vs. Remittances Trend (2000-2024)"
line.y_axis.title = "USD Billion"
line.x_axis.title = "Year"
data_ref2 = Reference(ws, min_col=3, max_col=4, min_row=h2, max_row=h2_end)
cats_ref2 = Reference(ws, min_col=2, min_row=h2 + 1, max_row=h2_end)
line.add_data(data_ref2, titles_from_data=True)
line.set_categories(cats_ref2)
line.width, line.height = 16, 9
ws.add_chart(line, f"F{note_row + 21}")

wb.save(OUT)
print("Executive Summary charts added.")

# =============================================================================
# SHEET: Executive Insights
# =============================================================================
ws_ins = wb.create_sheet("Executive Insights")
ws_ins.sheet_view.showGridLines = False
ws_ins["B2"] = "Executive Insights"
ws_ins["B2"].font = Font(name=FONT, size=18, bold=True, color=NAVY)
ws_ins["B3"] = "10 evidence-based findings, each with business impact and a recommendation."
ws_ins["B3"].font = Font(name=FONT, size=10.5, italic=True, color="666666")

insights = [
    ("1. UAE is the largest single destination for Indian migrants",
     "As of 2024, the UAE hosts an estimated 3.25 million Indian migrants, the highest of the "
     "7 countries tracked, narrowly ahead of the USA (3.17 million).",
     "The UAE corridor is disproportionately important to remittance flows and household income "
     "support in source states.",
     "Prioritize worker-protection agreements and skill-certification programs with the UAE "
     "given the scale of exposure."),
    ("2. Canada shows the fastest proportional growth of any tracked destination",
     "Canada's Indian migrant stock grew from 217,000 (2000) to 1.28 million (2024), a ~490% "
     "increase, the highest growth rate among all 7 countries.",
     "Canada has shifted from a minor destination to a top-3 corridor in two decades, driven by "
     "its points-based PR system and post-study work rights.",
     "Scale Canada-specific settlement and financial-literacy programs to match this growth."),
    ("3. The UK is the slowest-growing major destination",
     "UK migrant stock grew only ~70% between 2000 and 2024 (570,000 -> 970,000), far below "
     "every other tracked country.",
     "The UK's share of the total tracked Indian diaspora is shrinking relative to Canada, "
     "Australia, and the UAE, likely reflecting post-Brexit visa tightening.",
     "Flag the UK's comparatively constrained growth trajectory to prospective migrants against "
     "faster-expanding alternatives."),
    ("4. India's GDP grew 8.3x, but this coincided with rising, not falling, emigration",
     "India's GDP rose from $468B (2000) to $3.91T (2024) while migrant stock to these 7 "
     "destinations also rose sharply over the same period.",
     "Rising GDP alone is not a reliable predictor of reduced outward migration in this dataset "
     "- consistent with the globally observed 'migration hump.'",
     "Revisit policy framing that assumes GDP growth will organically curb migration."),
    ("5. Remittances grew over 10x, closely tracking GDP, not migrant headcount",
     "Remittances rose from $12.9B (2000) to $137.7B (2024), a ~10.7x increase, correlating "
     "strongly with India's GDP (r=0.98) and negatively with unemployment (r=-0.75).",
     "Remittance inflows are a resilient, expanding pillar of India's external finances, "
     "effectively decoupled from domestic unemployment cycles.",
     "Treat remittances as a structurally growing revenue stream; keep investing in low-cost "
     "remittance-channel infrastructure."),
    ("6. India's unemployment has been comparatively stable, with a 2020 spike and 2023 low",
     "Unemployment ranged narrowly between ~4.2% and ~7.9% across 2000-2024, spiking to 7.86% "
     "in 2020 and falling to a period-low 4.17% in 2023.",
     "Despite the 2020 shock, unemployment does not show a long-run deteriorating pattern over "
     "the 25-year window.",
     "Monitor the 2023 low for durability before treating it as a structural improvement."),
    ("7. UAE and Australia are the only countries where migrant stock declined between benchmarks",
     "The UAE's stock fell from 3.5M (2020) to 3.25M (2024), a rare contraction among tracked "
     "destinations.",
     "The UAE, while still the largest single destination, is the only tracked market showing "
     "net contraction risk, possibly tied to COVID-era return migration or labor localization "
     "policy.",
     "Treat the UAE corridor as maturing/plateauing rather than assuming continued high growth."),
    ("8. Workforce vs. student composition data is too sparse to generalize",
     "Only 2 of 182 country-year records have both Temporary Worker Share and Student Share "
     "populated (Australia 2020, UK 2024).",
     "Any dashboard claiming to show 'workforce vs. student migration trends' across all 7 "
     "countries would be showing mostly gaps, not signal.",
     "Flag this explicitly in any report using these fields; treat the 2 data points as "
     "anecdotes, not a trend."),
    ("9. GDP and Unemployment fields are national, not country-specific",
     "GDP_India and Unemployment_India repeat the same value across all 7 destination "
     "countries for a given year.",
     "Any correlation between these fields and a specific country's migrant stock reflects "
     "India-side conditions, not destination-country demand.",
     "Label these fields explicitly as 'India national indicator' to avoid misinterpretation."),
    ("10. Data completeness itself is a finding: 53% of raw cells are 'NOT AVAILABLE'",
     "Of 1,323 raw data cells, 703 (53.1%) are explicitly marked unavailable, concentrated in "
     "Permanent Migrants, Temporary Workers, and Students for most years.",
     "Any executive dashboard should surface data-completeness context rather than implying "
     "full annual coverage.",
     "Prioritize follow-up data sourcing for these sub-metrics if strategically important."),
]

headers = ["Insight", "What Happened", "Business Impact", "Recommendation"]
hr = 5
for j, h in enumerate(headers):
    cell = ws_ins.cell(row=hr, column=2 + j, value=h)
    cell.font = Font(name=FONT, size=10, bold=True, color=WHITE)
    cell.fill = PatternFill("solid", fgColor=NAVY)
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    cell.border = BORDER

for i, (title, what, impact, rec) in enumerate(insights):
    rr = hr + 1 + i
    values = [title, what, impact, rec]
    for j, v in enumerate(values):
        cell = ws_ins.cell(row=rr, column=2 + j, value=v)
        cell.font = Font(name=FONT, size=9.5, bold=(j == 0))
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        cell.border = BORDER
        if i % 2 == 1:
            cell.fill = PatternFill("solid", fgColor=GREY)
    ws_ins.row_dimensions[rr].height = 60

ws_ins.column_dimensions["B"].width = 34
for col in "CDE":
    ws_ins.column_dimensions[col].width = 38
ws_ins.freeze_panes = "B6"

wb.save(OUT)
print("Executive Insights sheet added.")

# =============================================================================
# SHEET: Data Quality Report
# =============================================================================
ws_dq = wb.create_sheet("Data Quality Report")
ws_dq.sheet_view.showGridLines = False
ws_dq["B2"] = "Data Quality Report"
ws_dq["B2"].font = Font(name=FONT, size=18, bold=True, color=NAVY)

dq_lines = [
    ("Source", "Raw_Data/indian_overseas_migration_dataset.csv - long format, one row per "
               "(Year, Destination Country, Metric)."),
    ("Total raw rows", "1,323"),
    ("Exact duplicate rows", "0"),
    ("Cells marked NOT AVAILABLE", "703 (53.1% of all cells)"),
    ("Rows missing a cited source", "703"),
    ("Mixed value formats found", "Plain numbers, percentages, and currency strings "
                                    "($468.40B and $1.217T) all stored as text in one column."),
    ("Reshape required", "Data was long-format (one metric per row); pivoted to one row "
                          "per Year x Country for analysis."),
]
r = 4
ws_dq[f"B{r}"] = "Issues Found (Before Cleaning)"
ws_dq[f"B{r}"].font = Font(name=FONT, size=12, bold=True, color=NAVY)
r += 1
for label, val in dq_lines:
    ws_dq[f"B{r}"] = label
    ws_dq[f"B{r}"].font = Font(name=FONT, size=10, bold=True)
    ws_dq[f"C{r}"] = val
    ws_dq[f"C{r}"].font = Font(name=FONT, size=10)
    ws_dq[f"C{r}"].alignment = Alignment(wrap_text=True)
    ws_dq.merge_cells(f"C{r}:H{r}")
    ws_dq.row_dimensions[r].height = 18
    r += 1

r += 1
ws_dq[f"B{r}"] = "Missing Values After Reshaping (per column)"
ws_dq[f"B{r}"].font = Font(name=FONT, size=12, bold=True, color=NAVY)
r += 1
hdr_r = r
ws_dq[f"B{hdr_r}"] = "Column"
ws_dq[f"C{hdr_r}"] = "Missing Count"
ws_dq[f"D{hdr_r}"] = "Missing %"
for cell_ref in [f"B{hdr_r}", f"C{hdr_r}", f"D{hdr_r}"]:
    ws_dq[cell_ref].font = Font(name=FONT, size=10, bold=True, color=WHITE)
    ws_dq[cell_ref].fill = PatternFill("solid", fgColor=NAVY)
r += 1
missing = df.isna().sum()
for col in df.columns:
    ws_dq[f"B{r}"] = col.replace("_", " ")
    ws_dq[f"C{r}"] = int(missing[col])
    ws_dq[f"D{r}"] = f"{missing[col]/len(df)*100:.1f}%"
    ws_dq[f"B{r}"].font = Font(name=FONT, size=9.5)
    ws_dq[f"C{r}"].font = Font(name=FONT, size=9.5)
    ws_dq[f"D{r}"].font = Font(name=FONT, size=9.5)
    r += 1

r += 1
ws_dq[f"B{r}"] = "Key Data Limitations"
ws_dq[f"B{r}"].font = Font(name=FONT, size=12, bold=True, color=NAVY)
r += 1
limitations = [
    "Scope: only 7 destination countries are covered - a sample of major corridors, not a "
    "complete global picture.",
    "Granularity: no Indian state-level, gender, age, or education breakdown exists in the "
    "source file.",
    "Migrant-count data (Permanent/Temporary/Students) is sparse, especially pre-2010.",
    "GDP_India and Unemployment_India are national figures, repeated across all 7 countries "
    "per year.",
    "Years extend to 2026; the most recent 1-2 years may be projections rather than finalized "
    "statistics.",
]
for lim in limitations:
    ws_dq[f"B{r}"] = f"-  {lim}"
    ws_dq[f"B{r}"].font = Font(name=FONT, size=10)
    ws_dq[f"B{r}"].alignment = Alignment(wrap_text=True)
    ws_dq.merge_cells(f"B{r}:H{r}")
    ws_dq.row_dimensions[r].height = 18
    r += 1

ws_dq.column_dimensions["B"].width = 30
for col in "CDEFGH":
    ws_dq.column_dimensions[col].width = 14

wb.save(OUT)
print("Data Quality Report sheet added.")

# =============================================================================
# SHEET: Data Dictionary
# =============================================================================
ws_dd = wb.create_sheet("Data Dictionary")
ws_dd.sheet_view.showGridLines = False
ws_dd["B2"] = "Data Dictionary"
ws_dd["B2"].font = Font(name=FONT, size=18, bold=True, color=NAVY)

dd_rows = [
    ("Year", "Calendar year of the record", "Full, 2000-2026"),
    ("Destination Country", "Short country name", "Full"),
    ("Destination Country Full", "Standardized full country name", "Full"),
    ("Region", "Geographic region of destination country", "Full"),
    ("Total Indian Migrants", "Estimated total stock of Indian-born migrants in that country",
     "Sparse - benchmark years only (2000, 2005/2010, 2015, 2020, 2024)"),
    ("Permanent Migrants", "Estimated permanent-resident migrants", "Very sparse"),
    ("Temporary Workers", "Estimated temporary/contract workers", "Very sparse"),
    ("Students", "Estimated Indian student population", "Very sparse"),
    ("Remittance USD Billion", "India-WIDE total remittances received (not country-specific)",
     "Near-full, 2000-2024"),
    ("Unemployment India", "India-WIDE national unemployment rate (%)", "Full"),
    ("GDP India USD Billion", "India-WIDE GDP in USD billions (normalized from mixed $B/$T "
     "source notation)", "Near-full, 2000-2024; 2025-2026 not yet available"),
    ("Migrant YoY Growth Pct", "% change in Total Indian Migrants vs. prior available record "
     "for that country", "Derived; inherits sparsity above"),
    ("Temporary Worker Share Pct", "Temporary Workers as % of Total Indian Migrants",
     "Derived; very sparse"),
    ("Student Share Pct", "Students as % of Total Indian Migrants", "Derived; very sparse"),
    ("Remittance per Migrant USD Th", "India-wide remittances / that country's migrant stock "
     "(thousands USD) - a rough proxy, NOT a country-specific remittance figure",
     "Derived; sparse"),
    ("Migrant 3yr Moving Avg", "3-observation rolling average of Total Indian Migrants per "
     "country", "Derived"),
    ("High Migration Flag", "'High' if Total Indian Migrants is at/above that country's own "
     "75th percentile, else 'Normal'", "Derived"),
    ("India Unemployment Category", "Bucketed unemployment rate: Low (<6%), Moderate (6-8%), "
     "High (>8%)", "Derived"),
]
headers = ["Column", "Description", "Source Coverage"]
hr = 4
for j, h in enumerate(headers):
    cell = ws_dd.cell(row=hr, column=2 + j, value=h)
    cell.font = Font(name=FONT, size=10, bold=True, color=WHITE)
    cell.fill = PatternFill("solid", fgColor=NAVY)
    cell.border = BORDER
for i, (col, desc, cov) in enumerate(dd_rows):
    rr = hr + 1 + i
    vals = [col, desc, cov]
    for j, v in enumerate(vals):
        cell = ws_dd.cell(row=rr, column=2 + j, value=v)
        cell.font = Font(name=FONT, size=9.5, bold=(j == 0))
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        cell.border = BORDER
        if i % 2 == 1:
            cell.fill = PatternFill("solid", fgColor=GREY)
    ws_dd.row_dimensions[rr].height = 32

ws_dd.column_dimensions["B"].width = 26
ws_dd.column_dimensions["C"].width = 55
ws_dd.column_dimensions["D"].width = 38
ws_dd.freeze_panes = "B5"

# Important interpretation notes
r2 = hr + 1 + len(dd_rows) + 2
ws_dd[f"B{r2}"] = "Important Interpretation Notes"
ws_dd[f"B{r2}"].font = Font(name=FONT, size=12, bold=True, color=NAVY)
notes = [
    "Remittance, Unemployment, and GDP fields are national (India-wide) figures, repeated "
    "identically across all 7 destination countries for a given year. Never sum them across "
    "countries.",
    "Total Indian Migrants and its sub-categories are only available for benchmark years - "
    "any year-over-year growth spans multi-year gaps, not annual change.",
    "All currency figures are normalized to USD Billions (source mixed $B and $T notation).",
]
for i, note in enumerate(notes):
    rr = r2 + 1 + i
    ws_dd[f"B{rr}"] = f"-  {note}"
    ws_dd[f"B{rr}"].font = Font(name=FONT, size=10)
    ws_dd[f"B{rr}"].alignment = Alignment(wrap_text=True)
    ws_dd.merge_cells(f"B{rr}:D{rr}")
    ws_dd.row_dimensions[rr].height = 30

wb.save(OUT)
print("Data Dictionary sheet added. Workbook complete:", OUT)
