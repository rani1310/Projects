"""
run_migration_dashboard.py
============================================================================
Indian Overseas Migration Analytics — self-contained dashboard launcher.

WHAT THIS FILE DOES
--------------------
1. Contains the full cleaned dataset (embedded below, no external files
   needed) and the executive insights.
2. Builds the same interactive HTML dashboard (KPI cards, filterable
   charts via Chart.js, insights panel) you saw as an artifact.
3. Starts a small local web server and opens it in your default browser.

HOW TO RUN
-----------
    python run_migration_dashboard.py

Then your browser should open automatically to:
    http://localhost:8765/migration_dashboard.html

If it doesn't open automatically, copy that URL into your browser.
Press Ctrl+C in the terminal to stop the server when you're done.

REQUIREMENTS
------------
Standard library only (csv, json, http.server, webbrowser) — nothing to
pip install. Works with any Python 3.8+, including running/debugging
directly inside VS Code (just hit Run, or F5).

WHY A LOCAL SERVER INSTEAD OF JUST OPENING THE HTML FILE DIRECTLY
-------------------------------------------------------------------
The dashboard would technically still render if you just double-clicked
the generated HTML file (opening it as file://), since all the data and
logic are self-contained in the page and Chart.js loads from a public
CDN. This script instead serves it over http://localhost so behavior is
identical to a real deployed site and there\'s no risk of a browser\'s
local-file security restrictions blocking anything.
============================================================================
"""

import csv
import io
import json
import http.server
import socketserver
import threading
import webbrowser
import os
import sys

PORT = 8765
OUTPUT_HTML_NAME = "migration_dashboard.html"

# =============================================================================
# STEP 1: Embedded cleaned dataset (182 rows, one per Year x Destination
# Country). This is the SAME data produced by the Python cleaning pipeline
# (01_clean_and_engineer.py) from earlier in this project — embedded here
# directly so this single file has no external dependencies.
# =============================================================================
CSV_DATA = """Year,Destination_Country,Region,GDP_India_USD_Billion,Permanent_Migrants,Remittance_USD_Billion,Students,Temporary_Workers,Total_Indian_Migrants,Unemployment_India,Destination_Country_Full,Migrant_YoY_Growth_Pct,Temporary_Worker_Share_Pct,Student_Share_Pct,Remittance_per_Migrant_USD_Th,Migrant_3yr_Moving_Avg,High_Migration_Flag,India_Unemployment_Category
2000,Australia,Oceania,468.4,,12.88,,,173000.0,7.62,Australia,,,,74.45086705202313,173000.0,Normal,Moderate (6-8%)
2001,Australia,Oceania,485.44,,14.27,,,,7.61,Australia,,,,,173000.0,Normal,Moderate (6-8%)
2002,Australia,Oceania,514.94,,15.74,,,,7.68,Australia,,,,,173000.0,Normal,Moderate (6-8%)
2003,Australia,Oceania,607.7,,21.0,,,,7.63,Australia,,,,,,Normal,Moderate (6-8%)
2004,Australia,Oceania,709.15,,18.75,,,,7.6,Australia,,,,,,Normal,Moderate (6-8%)
2005,Australia,Oceania,820.38,,22.13,,,,7.55,Australia,,,,,,Normal,Moderate (6-8%)
2006,Australia,Oceania,940.26,,28.33,,,,7.55,Australia,,,,,,Normal,Moderate (6-8%)
2007,Australia,Oceania,1217.0,,37.22,,,,7.56,Australia,,,,,,Normal,Moderate (6-8%)
2008,Australia,Oceania,1199.0,,49.98,,,,7.63,Australia,,,,,,Normal,Moderate (6-8%)
2009,Australia,Oceania,1342.0,,49.2,,,,7.64,Australia,,,,,,Normal,Moderate (6-8%)
2010,Australia,Oceania,1676.0,17000.0,53.48,,,330000.0,7.63,Australia,,,,162.06060606060606,330000.0,Normal,Moderate (6-8%)
2011,Australia,Oceania,1823.0,,62.5,,,,7.61,Australia,,,,,330000.0,Normal,Moderate (6-8%)
2012,Australia,Oceania,1828.0,,68.82,,,,7.64,Australia,,,,,330000.0,Normal,Moderate (6-8%)
2013,Australia,Oceania,1857.0,,69.97,,,,7.68,Australia,,,,,,Normal,Moderate (6-8%)
2014,Australia,Oceania,2039.0000000000002,,70.39,,,,7.66,Australia,,,,,,Normal,Moderate (6-8%)
2015,Australia,Oceania,2104.0,,68.91,,,448000.0,7.63,Australia,,,,153.81696428571428,448000.0,Normal,Moderate (6-8%)
2016,Australia,Oceania,2295.0,,62.74,,,,7.61,Australia,,,,,448000.0,Normal,Moderate (6-8%)
2017,Australia,Oceania,2651.0,33310.0,68.97,49469.0,16124.0,,7.63,Australia,,,,,448000.0,Normal,Moderate (6-8%)
2018,Australia,Oceania,2703.0,33611.0,78.79,66449.0,22357.0,,7.65,Australia,,,,,,Normal,Moderate (6-8%)
2019,Australia,Oceania,2836.0,25698.0,83.33,55560.0,13434.0,,6.51,Australia,,,,,,Normal,Moderate (6-8%)
2020,Australia,Oceania,2675.0,21791.0,83.15,47031.0,10071.0,721000.0,7.86,Australia,,1.3968099861303744,6.523023578363383,115.3259361997226,721000.0,High,Moderate (6-8%)
2021,Australia,Oceania,3167.0,24324.0,89.38,200325.0,18717.0,,6.38,Australia,,,,,721000.0,Normal,Moderate (6-8%)
2022,Australia,Oceania,3346.0,41145.0,111.22,357038.0,27402.0,,4.82,Australia,,,,,721000.0,Normal,Low (<6%)
2023,Australia,Oceania,3638.0,,119.53,287259.0,,,4.17,Australia,,,,,,Normal,Low (<6%)
2024,Australia,Oceania,3910.0,,137.67,302758.0,,916000.0,4.17,Australia,,,33.05218340611354,150.2947598253275,916000.0,High,Low (<6%)
2025,Australia,Oceania,,,,,,,4.22,Australia,,,,,916000.0,Normal,Low (<6%)
2000,Canada,North America,468.4,26122.0,12.88,,,217000.0,7.62,Canada,,,,59.354838709677416,217000.0,Normal,Moderate (6-8%)
2001,Canada,North America,485.44,,14.27,,,,7.61,Canada,,,,,217000.0,Normal,Moderate (6-8%)
2002,Canada,North America,514.94,,15.74,,,,7.68,Canada,,,,,217000.0,Normal,Moderate (6-8%)
2003,Canada,North America,607.7,,21.0,,,,7.63,Canada,,,,,,Normal,Moderate (6-8%)
2004,Canada,North America,709.15,,18.75,,,,7.6,Canada,,,,,,Normal,Moderate (6-8%)
2005,Canada,North America,820.38,,22.13,,,,7.55,Canada,,,,,,Normal,Moderate (6-8%)
2006,Canada,North America,940.26,,28.33,,,,7.55,Canada,,,,,,Normal,Moderate (6-8%)
2007,Canada,North America,1217.0,,37.22,,,,7.56,Canada,,,,,,Normal,Moderate (6-8%)
2008,Canada,North America,1199.0,,49.98,,,,7.63,Canada,,,,,,Normal,Moderate (6-8%)
2009,Canada,North America,1342.0,,49.2,,,,7.64,Canada,,,,,,Normal,Moderate (6-8%)
2010,Canada,North America,1676.0,30311.0,53.48,,,540000.0,7.63,Canada,,,,99.03703703703704,540000.0,Normal,Moderate (6-8%)
2011,Canada,North America,1823.0,,62.5,,,,7.61,Canada,,,,,540000.0,Normal,Moderate (6-8%)
2012,Canada,North America,1828.0,,68.82,,,,7.64,Canada,,,,,540000.0,Normal,Moderate (6-8%)
2013,Canada,North America,1857.0,,69.97,,,,7.68,Canada,,,,,,Normal,Moderate (6-8%)
2014,Canada,North America,2039.0000000000002,,70.39,,,,7.66,Canada,,,,,,Normal,Moderate (6-8%)
2015,Canada,North America,2104.0,39340.0,68.91,172600.0,,710000.0,7.63,Canada,,,24.309859154929576,97.05633802816901,710000.0,Normal,Moderate (6-8%)
2016,Canada,North America,2295.0,,62.74,,,,7.61,Canada,,,,,710000.0,Normal,Moderate (6-8%)
2017,Canada,North America,2651.0,,68.97,,,,7.63,Canada,,,,,710000.0,Normal,Moderate (6-8%)
2018,Canada,North America,2703.0,69985.0,78.79,,,,7.65,Canada,,,,,,Normal,Moderate (6-8%)
2019,Canada,North America,2836.0,85590.0,83.33,,,,6.51,Canada,,,,,,Normal,Moderate (6-8%)
2020,Canada,North America,2675.0,42875.0,83.15,,,1020000.0,7.86,Canada,,,,81.51960784313725,1020000.0,High,Moderate (6-8%)
2021,Canada,North America,3167.0,127945.0,89.38,,,,6.38,Canada,,,,,1020000.0,Normal,Moderate (6-8%)
2022,Canada,North America,3346.0,118250.0,111.22,,,,4.82,Canada,,,,,1020000.0,Normal,Low (<6%)
2023,Canada,North America,3638.0,139790.0,119.53,427000.0,,,4.17,Canada,,,,,,Normal,Low (<6%)
2024,Canada,North America,3910.0,127375.0,137.67,,,1280000.0,4.17,Canada,,,,107.5546875,1280000.0,High,Low (<6%)
2025,Canada,North America,,98825.0,,,,,4.22,Canada,,,,,1280000.0,Normal,Low (<6%)
2000,Germany,Europe,468.4,,12.88,,,,7.62,Germany,,,,,,Normal,Moderate (6-8%)
2001,Germany,Europe,485.44,,14.27,,,,7.61,Germany,,,,,,Normal,Moderate (6-8%)
2002,Germany,Europe,514.94,,15.74,,,,7.68,Germany,,,,,,Normal,Moderate (6-8%)
2003,Germany,Europe,607.7,,21.0,,,,7.63,Germany,,,,,,Normal,Moderate (6-8%)
2004,Germany,Europe,709.15,,18.75,,,,7.6,Germany,,,,,,Normal,Moderate (6-8%)
2005,Germany,Europe,820.38,,22.13,,,,7.55,Germany,,,,,,Normal,Moderate (6-8%)
2006,Germany,Europe,940.26,,28.33,,,,7.55,Germany,,,,,,Normal,Moderate (6-8%)
2007,Germany,Europe,1217.0,,37.22,,,,7.56,Germany,,,,,,Normal,Moderate (6-8%)
2008,Germany,Europe,1199.0,,49.98,,,,7.63,Germany,,,,,,Normal,Moderate (6-8%)
2009,Germany,Europe,1342.0,,49.2,,,,7.64,Germany,,,,,,Normal,Moderate (6-8%)
2010,Germany,Europe,1676.0,,53.48,,,60000.0,7.63,Germany,,,,891.3333333333334,60000.0,Normal,Moderate (6-8%)
2011,Germany,Europe,1823.0,,62.5,,,,7.61,Germany,,,,,60000.0,Normal,Moderate (6-8%)
2012,Germany,Europe,1828.0,,68.82,,,,7.64,Germany,,,,,60000.0,Normal,Moderate (6-8%)
2013,Germany,Europe,1857.0,,69.97,,,,7.68,Germany,,,,,,Normal,Moderate (6-8%)
2014,Germany,Europe,2039.0000000000002,,70.39,,,,7.66,Germany,,,,,,Normal,Moderate (6-8%)
2015,Germany,Europe,2104.0,,68.91,,,98000.0,7.63,Germany,,,,703.1632653061224,98000.0,Normal,Moderate (6-8%)
2016,Germany,Europe,2295.0,,62.74,,,,7.61,Germany,,,,,98000.0,Normal,Moderate (6-8%)
2017,Germany,Europe,2651.0,,68.97,,,,7.63,Germany,,,,,98000.0,Normal,Moderate (6-8%)
2018,Germany,Europe,2703.0,,78.79,,,,7.65,Germany,,,,,,Normal,Moderate (6-8%)
2019,Germany,Europe,2836.0,,83.33,,,,6.51,Germany,,,,,,Normal,Moderate (6-8%)
2020,Germany,Europe,2675.0,,83.15,28905.0,,210000.0,7.86,Germany,,,13.764285714285714,395.95238095238096,210000.0,Normal,Moderate (6-8%)
2021,Germany,Europe,3167.0,,89.38,,,,6.38,Germany,,,,,210000.0,Normal,Moderate (6-8%)
2022,Germany,Europe,3346.0,,111.22,,,,4.82,Germany,,,,,210000.0,Normal,Low (<6%)
2023,Germany,Europe,3638.0,,119.53,,,,4.17,Germany,,,,,,Normal,Low (<6%)
2024,Germany,Europe,3910.0,,137.67,,,285000.0,4.17,Germany,,,,483.05263157894734,285000.0,High,Low (<6%)
2025,Germany,Europe,,,,60000.0,,,4.22,Germany,,,,,285000.0,Normal,Low (<6%)
2000,Singapore,Asia,468.4,,12.88,,,85000.0,7.62,Singapore,,,,151.52941176470588,85000.0,Normal,Moderate (6-8%)
2001,Singapore,Asia,485.44,,14.27,,,,7.61,Singapore,,,,,85000.0,Normal,Moderate (6-8%)
2002,Singapore,Asia,514.94,,15.74,,,,7.68,Singapore,,,,,85000.0,Normal,Moderate (6-8%)
2003,Singapore,Asia,607.7,,21.0,,,,7.63,Singapore,,,,,,Normal,Moderate (6-8%)
2004,Singapore,Asia,709.15,,18.75,,,,7.6,Singapore,,,,,,Normal,Moderate (6-8%)
2005,Singapore,Asia,820.38,,22.13,,,,7.55,Singapore,,,,,,Normal,Moderate (6-8%)
2006,Singapore,Asia,940.26,,28.33,,,,7.55,Singapore,,,,,,Normal,Moderate (6-8%)
2007,Singapore,Asia,1217.0,,37.22,,,,7.56,Singapore,,,,,,Normal,Moderate (6-8%)
2008,Singapore,Asia,1199.0,,49.98,,,,7.63,Singapore,,,,,,Normal,Moderate (6-8%)
2009,Singapore,Asia,1342.0,,49.2,,,,7.64,Singapore,,,,,,Normal,Moderate (6-8%)
2010,Singapore,Asia,1676.0,,53.48,,,210000.0,7.63,Singapore,,,,254.66666666666666,210000.0,Normal,Moderate (6-8%)
2011,Singapore,Asia,1823.0,,62.5,,,,7.61,Singapore,,,,,210000.0,Normal,Moderate (6-8%)
2012,Singapore,Asia,1828.0,,68.82,,,,7.64,Singapore,,,,,210000.0,Normal,Moderate (6-8%)
2013,Singapore,Asia,1857.0,,69.97,,,,7.68,Singapore,,,,,,Normal,Moderate (6-8%)
2014,Singapore,Asia,2039.0000000000002,,70.39,,,,7.66,Singapore,,,,,,Normal,Moderate (6-8%)
2015,Singapore,Asia,2104.0,,68.91,,,310000.0,7.63,Singapore,,,,222.29032258064515,310000.0,Normal,Moderate (6-8%)
2016,Singapore,Asia,2295.0,,62.74,,,,7.61,Singapore,,,,,310000.0,Normal,Moderate (6-8%)
2017,Singapore,Asia,2651.0,,68.97,,,,7.63,Singapore,,,,,310000.0,Normal,Moderate (6-8%)
2018,Singapore,Asia,2703.0,,78.79,,,,7.65,Singapore,,,,,,Normal,Moderate (6-8%)
2019,Singapore,Asia,2836.0,,83.33,,,,6.51,Singapore,,,,,,Normal,Moderate (6-8%)
2020,Singapore,Asia,2675.0,,83.15,,,370000.0,7.86,Singapore,,,,224.72972972972974,370000.0,High,Moderate (6-8%)
2021,Singapore,Asia,3167.0,,89.38,,,,6.38,Singapore,,,,,370000.0,Normal,Moderate (6-8%)
2022,Singapore,Asia,3346.0,,111.22,,,,4.82,Singapore,,,,,370000.0,Normal,Low (<6%)
2023,Singapore,Asia,3638.0,,119.53,,,,4.17,Singapore,,,,,,Normal,Low (<6%)
2024,Singapore,Asia,3910.0,,137.67,,,395000.0,4.17,Singapore,,,,348.53164556962025,395000.0,High,Low (<6%)
2025,Singapore,Asia,,,,,,,4.22,Singapore,,,,,395000.0,Normal,Low (<6%)
2000,UAE,Middle East,468.4,,12.88,,,950000.0,7.62,United Arab Emirates,,,,13.557894736842105,950000.0,Normal,Moderate (6-8%)
2001,UAE,Middle East,485.44,,14.27,,,,7.61,United Arab Emirates,,,,,950000.0,Normal,Moderate (6-8%)
2002,UAE,Middle East,514.94,,15.74,,,,7.68,United Arab Emirates,,,,,950000.0,Normal,Moderate (6-8%)
2003,UAE,Middle East,607.7,,21.0,,,,7.63,United Arab Emirates,,,,,,Normal,Moderate (6-8%)
2004,UAE,Middle East,709.15,,18.75,,,,7.6,United Arab Emirates,,,,,,Normal,Moderate (6-8%)
2005,UAE,Middle East,820.38,,22.13,,,,7.55,United Arab Emirates,,,,,,Normal,Moderate (6-8%)
2006,UAE,Middle East,940.26,,28.33,,,,7.55,United Arab Emirates,,,,,,Normal,Moderate (6-8%)
2007,UAE,Middle East,1217.0,,37.22,,,,7.56,United Arab Emirates,,,,,,Normal,Moderate (6-8%)
2008,UAE,Middle East,1199.0,,49.98,,,,7.63,United Arab Emirates,,,,,,Normal,Moderate (6-8%)
2009,UAE,Middle East,1342.0,,49.2,,,,7.64,United Arab Emirates,,,,,,Normal,Moderate (6-8%)
2010,UAE,Middle East,1676.0,,53.48,,,2250000.0,7.63,United Arab Emirates,,,,23.76888888888889,2250000.0,Normal,Moderate (6-8%)
2011,UAE,Middle East,1823.0,,62.5,,,,7.61,United Arab Emirates,,,,,2250000.0,Normal,Moderate (6-8%)
2012,UAE,Middle East,1828.0,,68.82,,,,7.64,United Arab Emirates,,,,,2250000.0,Normal,Moderate (6-8%)
2013,UAE,Middle East,1857.0,,69.97,,,,7.68,United Arab Emirates,,,,,,Normal,Moderate (6-8%)
2014,UAE,Middle East,2039.0000000000002,,70.39,,,,7.66,United Arab Emirates,,,,,,Normal,Moderate (6-8%)
2015,UAE,Middle East,2104.0,,68.91,,,2800000.0,7.63,United Arab Emirates,,,,24.610714285714284,2800000.0,Normal,Moderate (6-8%)
2016,UAE,Middle East,2295.0,,62.74,,,,7.61,United Arab Emirates,,,,,2800000.0,Normal,Moderate (6-8%)
2017,UAE,Middle East,2651.0,,68.97,,,,7.63,United Arab Emirates,,,,,2800000.0,Normal,Moderate (6-8%)
2018,UAE,Middle East,2703.0,,78.79,,,,7.65,United Arab Emirates,,,,,,Normal,Moderate (6-8%)
2019,UAE,Middle East,2836.0,,83.33,,,,6.51,United Arab Emirates,,,,,,Normal,Moderate (6-8%)
2020,UAE,Middle East,2675.0,,83.15,,,3500000.0,7.86,United Arab Emirates,,,,23.757142857142856,3500000.0,High,Moderate (6-8%)
2021,UAE,Middle East,3167.0,,89.38,,,,6.38,United Arab Emirates,,,,,3500000.0,Normal,Moderate (6-8%)
2022,UAE,Middle East,3346.0,,111.22,,,,4.82,United Arab Emirates,,,,,3500000.0,Normal,Low (<6%)
2023,UAE,Middle East,3638.0,,119.53,,,,4.17,United Arab Emirates,,,,,,Normal,Low (<6%)
2024,UAE,Middle East,3910.0,,137.67,,,3250000.0,4.17,United Arab Emirates,,,,42.36,3250000.0,High,Low (<6%)
2025,UAE,Middle East,,,,,,,4.22,United Arab Emirates,,,,,3250000.0,Normal,Low (<6%)
2000,UK,Europe,468.4,,12.88,,,570000.0,7.62,United Kingdom,,,,22.596491228070175,570000.0,Normal,Moderate (6-8%)
2001,UK,Europe,485.44,,14.27,,,,7.61,United Kingdom,,,,,570000.0,Normal,Moderate (6-8%)
2002,UK,Europe,514.94,,15.74,,,,7.68,United Kingdom,,,,,570000.0,Normal,Moderate (6-8%)
2003,UK,Europe,607.7,,21.0,,,,7.63,United Kingdom,,,,,,Normal,Moderate (6-8%)
2004,UK,Europe,709.15,,18.75,,,,7.6,United Kingdom,,,,,,Normal,Moderate (6-8%)
2005,UK,Europe,820.38,,22.13,,,,7.55,United Kingdom,,,,,,Normal,Moderate (6-8%)
2006,UK,Europe,940.26,,28.33,,,,7.55,United Kingdom,,,,,,Normal,Moderate (6-8%)
2007,UK,Europe,1217.0,,37.22,,,,7.56,United Kingdom,,,,,,Normal,Moderate (6-8%)
2008,UK,Europe,1199.0,,49.98,,,,7.63,United Kingdom,,,,,,Normal,Moderate (6-8%)
2009,UK,Europe,1342.0,,49.2,,,,7.64,United Kingdom,,,,,,Normal,Moderate (6-8%)
2010,UK,Europe,1676.0,,53.48,,,710000.0,7.63,United Kingdom,,,,75.32394366197182,710000.0,Normal,Moderate (6-8%)
2011,UK,Europe,1823.0,,62.5,,,,7.61,United Kingdom,,,,,710000.0,Normal,Moderate (6-8%)
2012,UK,Europe,1828.0,,68.82,,,,7.64,United Kingdom,,,,,710000.0,Normal,Moderate (6-8%)
2013,UK,Europe,1857.0,,69.97,,,,7.68,United Kingdom,,,,,,Normal,Moderate (6-8%)
2014,UK,Europe,2039.0000000000002,,70.39,,,,7.66,United Kingdom,,,,,,Normal,Moderate (6-8%)
2015,UK,Europe,2104.0,,68.91,,,800000.0,7.63,United Kingdom,,,,86.1375,800000.0,Normal,Moderate (6-8%)
2016,UK,Europe,2295.0,,62.74,,,,7.61,United Kingdom,,,,,800000.0,Normal,Moderate (6-8%)
2017,UK,Europe,2651.0,,68.97,,,,7.63,United Kingdom,,,,,800000.0,Normal,Moderate (6-8%)
2018,UK,Europe,2703.0,,78.79,,,,7.65,United Kingdom,,,,,,Normal,Moderate (6-8%)
2019,UK,Europe,2836.0,,83.33,,57087.0,,6.51,United Kingdom,,,,,,Normal,Moderate (6-8%)
2020,UK,Europe,2675.0,,83.15,,31238.0,890000.0,7.86,United Kingdom,,3.5098876404494384,,93.42696629213484,890000.0,High,Moderate (6-8%)
2021,UK,Europe,3167.0,,89.38,,64839.0,,6.38,United Kingdom,,,,,890000.0,Normal,Moderate (6-8%)
2022,UK,Europe,3346.0,,111.22,,59944.0,,4.82,United Kingdom,,,,,890000.0,Normal,Low (<6%)
2023,UK,Europe,3638.0,,119.53,159371.0,162655.0,,4.17,United Kingdom,,,,,,Normal,Low (<6%)
2024,UK,Europe,3910.0,,137.67,92355.0,81463.0,970000.0,4.17,United Kingdom,,8.398247422680411,9.521134020618556,141.9278350515464,970000.0,High,Low (<6%)
2025,UK,Europe,,,,,,,4.22,United Kingdom,,,,,970000.0,Normal,Low (<6%)
2000,USA,North America,468.4,,12.88,,,1005000.0,7.62,United States,,,,12.81592039800995,1005000.0,Normal,Moderate (6-8%)
2001,USA,North America,485.44,,14.27,,,,7.61,United States,,,,,1005000.0,Normal,Moderate (6-8%)
2002,USA,North America,514.94,,15.74,,,,7.68,United States,,,,,1005000.0,Normal,Moderate (6-8%)
2003,USA,North America,607.7,,21.0,,,,7.63,United States,,,,,,Normal,Moderate (6-8%)
2004,USA,North America,709.15,,18.75,,,,7.6,United States,,,,,,Normal,Moderate (6-8%)
2005,USA,North America,820.38,,22.13,,,1390000.0,7.55,United States,,,,15.920863309352518,1390000.0,Normal,Moderate (6-8%)
2006,USA,North America,940.26,,28.33,,,,7.55,United States,,,,,1390000.0,Normal,Moderate (6-8%)
2007,USA,North America,1217.0,,37.22,,,,7.56,United States,,,,,1390000.0,Normal,Moderate (6-8%)
2008,USA,North America,1199.0,,49.98,,,,7.63,United States,,,,,,Normal,Moderate (6-8%)
2009,USA,North America,1342.0,,49.2,,,,7.64,United States,,,,,,Normal,Moderate (6-8%)
2010,USA,North America,1676.0,,53.48,,,2060000.0,7.63,United States,,,,25.961165048543688,2060000.0,Normal,Moderate (6-8%)
2011,USA,North America,1823.0,,62.5,,,,7.61,United States,,,,,2060000.0,Normal,Moderate (6-8%)
2012,USA,North America,1828.0,,68.82,,,,7.64,United States,,,,,2060000.0,Normal,Moderate (6-8%)
2013,USA,North America,1857.0,,69.97,,,,7.68,United States,,,,,,Normal,Moderate (6-8%)
2014,USA,North America,2039.0000000000002,,70.39,,,,7.66,United States,,,,,,Normal,Moderate (6-8%)
2015,USA,North America,2104.0,,68.91,165918.0,,2400000.0,7.63,United States,,,6.91325,28.7125,2400000.0,Normal,Moderate (6-8%)
2016,USA,North America,2295.0,,62.74,186267.0,,,7.61,United States,,,,,2400000.0,Normal,Moderate (6-8%)
2017,USA,North America,2651.0,,68.97,196271.0,,,7.63,United States,,,,,2400000.0,Normal,Moderate (6-8%)
2018,USA,North America,2703.0,,78.79,202014.0,,,7.65,United States,,,,,,Normal,Moderate (6-8%)
2019,USA,North America,2836.0,,83.33,193124.0,,,6.51,United States,,,,,,Normal,Moderate (6-8%)
2020,USA,North America,2675.0,,83.15,167582.0,,2700000.0,7.86,United States,,,6.206740740740741,30.796296296296298,2700000.0,High,Moderate (6-8%)
2021,USA,North America,3167.0,,89.38,199182.0,,,6.38,United States,,,,,2700000.0,Normal,Moderate (6-8%)
2022,USA,North America,3346.0,,111.22,268923.0,,,4.82,United States,,,,,2700000.0,Normal,Low (<6%)
2023,USA,North America,3638.0,,119.53,331602.0,,,4.17,United States,,,,,,Normal,Low (<6%)
2024,USA,North America,3910.0,,137.67,,,3170000.0,4.17,United States,,,,43.429022082018925,3170000.0,High,Low (<6%)
2025,USA,North America,,,,,,,4.22,United States,,,,,3170000.0,Normal,Low (<6%)
"""

# =============================================================================
# STEP 2: Executive insights (same 10 findings from the analysis)
# =============================================================================
INSIGHTS = [
  {
    "title": "1. UAE is the largest single destination for Indian migrants",
    "body": "As of 2024, the UAE hosts an estimated 3.25 million Indian migrants, the highest of the 7 tracked countries, narrowly ahead of the USA (3.17 million)."
  },
  {
    "title": "2. Canada shows the fastest proportional growth",
    "body": "Canada's Indian migrant stock grew from 217,000 (2000) to 1.28 million (2024) \u2014 a ~490% increase, the highest growth rate tracked."
  },
  {
    "title": "3. The UK is the slowest-growing major destination",
    "body": "UK migrant stock grew only ~70% between 2000 and 2024 (570,000 \u2192 970,000), far below every other tracked country \u2014 likely tied to post-Brexit visa tightening."
  },
  {
    "title": "4. India's GDP grew 8.3x without slowing emigration",
    "body": "India's GDP rose from $468B (2000) to $3.91T (2024) while migrant stock to these 7 destinations also rose sharply \u2014 consistent with the globally observed 'migration hump.'"
  },
  {
    "title": "5. Remittances grew ~10.7x, tracking GDP more than headcount",
    "body": "Remittances rose from $12.9B to $137.7B (2000\u20132024), correlating strongly with India's GDP (r\u22480.98) and negatively with unemployment (r\u2248-0.75)."
  },
  {
    "title": "6. Unemployment has been comparatively stable",
    "body": "India's unemployment ranged narrowly between ~4.2% and ~7.9% (2000\u20132024), spiking in 2020 (COVID-19) and hitting a period-low in 2023."
  },
  {
    "title": "7. UAE and Australia show rare contraction between benchmarks",
    "body": "The UAE's migrant stock fell from 3.5M (2020) to 3.25M (2024) \u2014 the only tracked market showing net contraction risk, possibly tied to COVID-era return migration or labor localization policy."
  },
  {
    "title": "8. Workforce vs. student composition data is too sparse to generalize",
    "body": "Only 2 of 182 country-year records have both Temporary Worker Share and Student Share populated \u2014 treat any claim about this split as anecdotal, not trend."
  },
  {
    "title": "9. GDP and Unemployment fields are India-wide, not country-specific",
    "body": "These fields repeat identically across all 7 countries for a given year \u2014 they describe conditions in India, not destination-country demand."
  },
  {
    "title": "10. 53% of raw data cells were unavailable",
    "body": "Of 1,323 raw cells, 703 were explicitly marked unavailable \u2014 this dashboard surfaces only what the data actually supports, filtered live as you apply country/region filters above."
  }
]


def load_data_as_records():
    """Parse the embedded CSV into a list of dicts with correct types
    (numbers as float/int, blanks as None) — mirrors what pandas would
    produce, using only the standard library so no pip install is needed."""
    reader = csv.DictReader(io.StringIO(CSV_DATA))
    numeric_cols = {
        "Year", "GDP_India_USD_Billion", "Permanent_Migrants",
        "Remittance_USD_Billion", "Students", "Temporary_Workers",
        "Total_Indian_Migrants", "Unemployment_India",
        "Migrant_YoY_Growth_Pct", "Temporary_Worker_Share_Pct",
        "Student_Share_Pct", "Remittance_per_Migrant_USD_Th",
        "Migrant_3yr_Moving_Avg",
    }
    records = []
    for row in reader:
        clean = {}
        for key, val in row.items():
            if val is None or val == "":
                clean[key] = None
            elif key in numeric_cols:
                try:
                    num = float(val)
                    clean[key] = int(num) if key == "Year" else num
                except ValueError:
                    clean[key] = None
            else:
                clean[key] = val
        records.append(clean)
    return records


# =============================================================================
# STEP 3: HTML dashboard template (identical structure to the artifact
# version) — Chart.js loaded from CDN, everything else self-contained.
# =============================================================================
HTML_TEMPLATE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Indian Overseas Migration Analytics — Interactive Dashboard</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<style>
  :root {
    --navy: #16233F;
    --navy-light: #24365C;
    --paper: #F7F5F0;
    --card: #FFFFFF;
    --saffron: #E08E1D;
    --saffron-dark: #B96F0F;
    --teal: #2E7D6B;
    --ink: #1B1F27;
    --muted: #6B7280;
    --line: #E5E1D8;
    --danger: #B84A3E;
  }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    background: var(--paper);
    color: var(--ink);
    font-family: "Segoe UI", ui-sans-serif, system-ui, -apple-system, Arial, sans-serif;
  }
  .wrap { max-width: 1180px; margin: 0 auto; padding: 32px 24px 60px; }

  header.top {
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    flex-wrap: wrap;
    gap: 16px;
    border-bottom: 3px solid var(--navy);
    padding-bottom: 18px;
    margin-bottom: 26px;
  }
  header.top .eyebrow {
    text-transform: uppercase;
    letter-spacing: 0.12em;
    font-size: 12px;
    color: var(--saffron-dark);
    font-weight: 700;
    margin-bottom: 4px;
  }
  header.top h1 {
    margin: 0;
    font-size: 28px;
    color: var(--navy);
    letter-spacing: -0.01em;
  }
  header.top .sub {
    color: var(--muted);
    font-size: 13.5px;
    margin-top: 4px;
  }
  .scope-note {
    font-size: 12.5px;
    color: var(--muted);
    max-width: 340px;
    text-align: right;
    line-height: 1.45;
  }

  .kpi-row {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 12px;
    margin-bottom: 28px;
  }
  .kpi {
    background: var(--card);
    border: 1px solid var(--line);
    border-top: 3px solid var(--saffron);
    border-radius: 4px;
    padding: 14px 16px;
  }
  .kpi .label { font-size: 11.5px; text-transform: uppercase; letter-spacing: 0.05em; color: var(--muted); font-weight: 600;}
  .kpi .value { font-size: 24px; font-weight: 700; color: var(--navy); margin-top: 4px; font-variant-numeric: tabular-nums;}

  .filters {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    align-items: center;
    background: var(--card);
    border: 1px solid var(--line);
    border-radius: 4px;
    padding: 14px 16px;
    margin-bottom: 24px;
  }
  .filters .group-label { font-size: 12px; font-weight: 700; color: var(--navy); margin-right: 4px; }
  .chip {
    border: 1.5px solid var(--line);
    background: var(--paper);
    color: var(--ink);
    padding: 5px 12px;
    border-radius: 999px;
    font-size: 12.5px;
    cursor: pointer;
    user-select: none;
    transition: all 0.12s ease;
  }
  .chip:hover { border-color: var(--saffron); }
  .chip.active {
    background: var(--navy);
    border-color: var(--navy);
    color: white;
  }
  .filters .reset {
    margin-left: auto;
    font-size: 12px;
    color: var(--saffron-dark);
    cursor: pointer;
    font-weight: 600;
    text-decoration: underline;
  }

  .grid2 {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 18px;
    margin-bottom: 18px;
  }
  @media (max-width: 860px) { .grid2 { grid-template-columns: 1fr; } }

  .card {
    background: var(--card);
    border: 1px solid var(--line);
    border-radius: 4px;
    padding: 18px 18px 8px;
  }
  .card h3 {
    margin: 0 0 2px;
    font-size: 14.5px;
    color: var(--navy);
  }
  .card .card-note { font-size: 11.5px; color: var(--muted); margin-bottom: 10px; }
  canvas { max-height: 280px; }

  .insights {
    background: var(--card);
    border: 1px solid var(--line);
    border-radius: 4px;
    padding: 20px 22px;
    margin-top: 8px;
  }
  .insights h2 {
    font-size: 17px;
    color: var(--navy);
    margin-top: 0;
    border-bottom: 2px solid var(--saffron);
    padding-bottom: 8px;
    display: inline-block;
  }
  .insight-item {
    border-left: 3px solid var(--teal);
    padding: 4px 0 4px 14px;
    margin: 14px 0;
  }
  .insight-item .t { font-weight: 700; font-size: 13.5px; color: var(--navy); }
  .insight-item .b { font-size: 12.8px; color: var(--ink); margin-top: 3px; line-height: 1.5; }

  footer.note {
    margin-top: 26px;
    font-size: 11.5px;
    color: var(--muted);
    border-top: 1px solid var(--line);
    padding-top: 12px;
    line-height: 1.5;
  }
</style>
</head>
<body>
<div class="wrap">

  <header class="top">
    <div>
      <div class="eyebrow">Executive Dashboard</div>
      <h1>Indian Overseas Migration Analytics</h1>
      <div class="sub">2000–2024 · 7 destination countries · Free, interactive, no login required</div>
    </div>
    <div class="scope-note">
      Migrant-stock figures recorded only in benchmark years. GDP, remittances, and unemployment are India-wide national figures, not country-specific.
    </div>
  </header>

  <div class="kpi-row" id="kpiRow"></div>

  <div class="filters">
    <span class="group-label">Country</span>
    <div id="countryChips"></div>
    <span class="group-label" style="margin-left:14px;">Region</span>
    <div id="regionChips"></div>
    <span class="reset" id="resetBtn">Reset filters</span>
  </div>

  <div class="grid2">
    <div class="card">
      <h3>Indian Migrant Stock by Country (2024)</h3>
      <div class="card-note">Latest benchmark year available per country</div>
      <canvas id="chartMigrants"></canvas>
    </div>
    <div class="card">
      <h3>India GDP vs. Remittances Trend</h3>
      <div class="card-note">Annual, 2000–2024, USD Billion</div>
      <canvas id="chartTrend"></canvas>
    </div>
  </div>

  <div class="grid2">
    <div class="card">
      <h3>Migrant Stock by Region (Benchmark Years)</h3>
      <div class="card-note">Stacked totals across tracked countries</div>
      <canvas id="chartRegion"></canvas>
    </div>
    <div class="card">
      <h3>India Unemployment Rate</h3>
      <div class="card-note">Annual %, 2000–2024</div>
      <canvas id="chartUnemployment"></canvas>
    </div>
  </div>

  <div class="insights" id="insightsPanel">
    <h2>Executive Insights</h2>
    <!-- injected -->
  </div>

  <footer class="note">
    Source: public migration/remittance/macro-indicator estimates compiled 2000–2026 (7 countries). 53% of raw source cells were marked unavailable and are excluded here — see the accompanying Data Quality Report for full detail. Built as a free, standalone dashboard: no account, server, or Power BI license needed to view it.
  </footer>

</div>

<script>
const DATA = __DATA_JSON__;
const INSIGHTS = __INSIGHTS_JSON__;

const COUNTRY_COLORS = {
  "USA": "#16233F", "Canada": "#E08E1D", "UK": "#2E7D6B",
  "Australia": "#B84A3E", "UAE": "#7A5C9E", "Germany": "#946B4A", "Singapore": "#3C7FA6"
};

let state = { countries: new Set(), regions: new Set() };
const allCountries = [...new Set(DATA.map(d => d.Destination_Country))].sort();
const allRegions = [...new Set(DATA.map(d => d.Region))].sort();

function filteredData() {
  return DATA.filter(d =>
    (state.countries.size === 0 || state.countries.has(d.Destination_Country)) &&
    (state.regions.size === 0 || state.regions.has(d.Region))
  );
}

function buildChips(containerId, items, setRef) {
  const el = document.getElementById(containerId);
  el.style.display = "inline-flex";
  el.style.gap = "6px";
  el.style.flexWrap = "wrap";
  items.forEach(item => {
    const chip = document.createElement("span");
    chip.className = "chip";
    chip.textContent = item;
    chip.onclick = () => {
      if (setRef.has(item)) { setRef.delete(item); chip.classList.remove("active"); }
      else { setRef.add(item); chip.classList.add("active"); }
      renderAll();
    };
    el.appendChild(chip);
  });
}
buildChips("countryChips", allCountries, state.countries);
buildChips("regionChips", allRegions, state.regions);

document.getElementById("resetBtn").onclick = () => {
  state.countries.clear(); state.regions.clear();
  document.querySelectorAll(".chip").forEach(c => c.classList.remove("active"));
  renderAll();
};

let charts = {};
function destroyCharts() { Object.values(charts).forEach(c => c && c.destroy()); charts = {}; }

function renderKPIs(rows) {
  const latestYear = Math.max(...rows.filter(r => r.Total_Indian_Migrants != null).map(r => r.Year), 0);
  const totalMigrants2024 = rows.filter(r => r.Year === 2024 && r.Total_Indian_Migrants != null)
    .reduce((s, r) => s + r.Total_Indian_Migrants, 0);
  const countries = new Set(rows.map(r => r.Destination_Country)).size;
  const gdp2024row = rows.find(r => r.Year === 2024 && r.GDP_India_USD_Billion != null);
  const rem2024row = rows.find(r => r.Year === 2024 && r.Remittance_USD_Billion != null);
  const kpis = [
    ["Records in View", rows.length.toLocaleString()],
    ["Countries in View", countries],
    ["Latest Migrant-Stock Year", latestYear || "—"],
    ["Total Migrants, 2024", totalMigrants2024 ? totalMigrants2024.toLocaleString() : "—"],
    ["India GDP 2024 ($B)", gdp2024row ? gdp2024row.GDP_India_USD_Billion.toLocaleString() : "—"],
    ["Remittances 2024 ($B)", rem2024row ? rem2024row.Remittance_USD_Billion.toFixed(1) : "—"],
  ];
  const row = document.getElementById("kpiRow");
  row.innerHTML = "";
  kpis.forEach(([label, value]) => {
    const div = document.createElement("div");
    div.className = "kpi";
    div.innerHTML = `<div class="label">${label}</div><div class="value">${value}</div>`;
    row.appendChild(div);
  });
}

function renderMigrantsChart(rows) {
  const byCountry = {};
  rows.filter(r => r.Total_Indian_Migrants != null).forEach(r => {
    if (!byCountry[r.Destination_Country] || r.Year > byCountry[r.Destination_Country].Year) {
      byCountry[r.Destination_Country] = r;
    }
  });
  const entries = Object.values(byCountry).sort((a,b) => b.Total_Indian_Migrants - a.Total_Indian_Migrants);
  const ctx = document.getElementById("chartMigrants");
  charts.migrants = new Chart(ctx, {
    type: "bar",
    data: {
      labels: entries.map(e => `${e.Destination_Country} ('${String(e.Year).slice(2)})`),
      datasets: [{
        data: entries.map(e => e.Total_Indian_Migrants),
        backgroundColor: entries.map(e => COUNTRY_COLORS[e.Destination_Country] || "#999")
      }]
    },
    options: {
      indexAxis: "y",
      plugins: { legend: { display: false } },
      scales: { x: { ticks: { callback: v => (v/1e6).toFixed(1)+"M" } } }
    }
  });
}

function renderTrendChart(rows) {
  const years = [...new Set(rows.map(r => r.Year))].filter(y => y <= 2024).sort((a,b)=>a-b);
  const gdpByYear = {}, remByYear = {};
  years.forEach(y => {
    const yr = rows.filter(r => r.Year === y);
    const gdpVals = yr.filter(r => r.GDP_India_USD_Billion != null).map(r => r.GDP_India_USD_Billion);
    const remVals = yr.filter(r => r.Remittance_USD_Billion != null).map(r => r.Remittance_USD_Billion);
    gdpByYear[y] = gdpVals.length ? gdpVals.reduce((a,b)=>a+b,0)/gdpVals.length : null;
    remByYear[y] = remVals.length ? remVals.reduce((a,b)=>a+b,0)/remVals.length : null;
  });
  const ctx = document.getElementById("chartTrend");
  charts.trend = new Chart(ctx, {
    type: "line",
    data: {
      labels: years,
      datasets: [
        { label: "India GDP ($B)", data: years.map(y => gdpByYear[y]), borderColor: "#16233F", backgroundColor: "#16233F22", yAxisID: "y", tension: 0.25 },
        { label: "Remittances ($B)", data: years.map(y => remByYear[y]), borderColor: "#E08E1D", backgroundColor: "#E08E1D22", yAxisID: "y1", tension: 0.25 }
      ]
    },
    options: {
      interaction: { mode: "index", intersect: false },
      scales: {
        y: { type: "linear", position: "left", title: { display: true, text: "GDP ($B)" } },
        y1: { type: "linear", position: "right", grid: { drawOnChartArea: false }, title: { display: true, text: "Remittances ($B)" } }
      }
    }
  });
}

function renderRegionChart(rows) {
  const benchmarkYears = [2000, 2005, 2010, 2015, 2020, 2024];
  const regions = [...new Set(rows.map(r => r.Region))];
  const regionColors = { "North America":"#16233F", "Europe":"#2E7D6B", "Middle East":"#E08E1D", "Oceania":"#B84A3E", "Asia":"#3C7FA6" };
  const datasets = regions.map(reg => ({
    label: reg,
    backgroundColor: regionColors[reg] || "#999",
    data: benchmarkYears.map(y => {
      const vals = rows.filter(r => r.Year === y && r.Region === reg && r.Total_Indian_Migrants != null);
      return vals.reduce((s, r) => s + r.Total_Indian_Migrants, 0);
    })
  }));
  const ctx = document.getElementById("chartRegion");
  charts.region = new Chart(ctx, {
    type: "bar",
    data: { labels: benchmarkYears, datasets },
    options: { scales: { x: { stacked: true }, y: { stacked: true, ticks: { callback: v => (v/1e6).toFixed(1)+"M" } } } }
  });
}

function renderUnemploymentChart(rows) {
  const years = [...new Set(rows.map(r => r.Year))].filter(y => y <= 2024).sort((a,b)=>a-b);
  const byYear = {};
  years.forEach(y => {
    const vals = rows.filter(r => r.Year === y && r.Unemployment_India != null).map(r => r.Unemployment_India);
    byYear[y] = vals.length ? vals[0] : null;
  });
  const ctx = document.getElementById("chartUnemployment");
  charts.unemp = new Chart(ctx, {
    type: "line",
    data: { labels: years, datasets: [{ label: "Unemployment (%)", data: years.map(y => byYear[y]), borderColor: "#B84A3E", backgroundColor: "#B84A3E22", fill: true, tension: 0.25 }] },
    options: { plugins: { legend: { display: false } } }
  });
}

function renderInsights() {
  const panel = document.getElementById("insightsPanel");
  panel.innerHTML = "<h2>Executive Insights</h2>" + INSIGHTS.map(i =>
    `<div class="insight-item"><div class="t">${i.title}</div><div class="b">${i.body}</div></div>`
  ).join("");
}

function renderAll() {
  const rows = filteredData();
  destroyCharts();
  renderKPIs(rows);
  renderMigrantsChart(rows);
  renderTrendChart(rows);
  renderRegionChart(rows);
  renderUnemploymentChart(rows);
}

renderInsights();
renderAll();
</script>
</body>
</html>
"""


def build_dashboard_html():
    """Inject the parsed data + insights into the HTML template and write
    the finished dashboard file to the same folder as this script."""
    records = load_data_as_records()
    data_json = json.dumps(records)
    insights_json = json.dumps(INSIGHTS)

    html = HTML_TEMPLATE.replace("__DATA_JSON__", data_json)
    html = html.replace("__INSIGHTS_JSON__", insights_json)

    script_dir = os.path.dirname(os.path.abspath(__file__))
    out_path = os.path.join(script_dir, OUTPUT_HTML_NAME)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"Dashboard built: {out_path}")
    return script_dir


def serve_and_open(directory, port=PORT):
    """Start a local HTTP server in `directory` and open the dashboard
    in the default browser."""
    os.chdir(directory)
    handler = http.server.SimpleHTTPRequestHandler

    # Try the preferred port; fall back to the next few if it's busy
    for attempt_port in range(port, port + 10):
        try:
            httpd = socketserver.TCPServer(("", attempt_port), handler)
            port = attempt_port
            break
        except OSError:
            continue
    else:
        print("Could not find a free port. Please close other local servers and retry.")
        sys.exit(1)

    url = f"http://localhost:{port}/{OUTPUT_HTML_NAME}"
    print(f"Serving dashboard at {url}")
    print("Press Ctrl+C to stop the server.")

    threading.Timer(0.6, lambda: webbrowser.open(url)).start()

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping server...")
        httpd.shutdown()


if __name__ == "__main__":
    folder = build_dashboard_html()
    serve_and_open(folder)
